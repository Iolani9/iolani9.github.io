# Chris's Student Site

This is a coded static website created as part of an in-class exercise during my summer Web Design Studio class

[View my Site](https://iolanichris.github.io/)
